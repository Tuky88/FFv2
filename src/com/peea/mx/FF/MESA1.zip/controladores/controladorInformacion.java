/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.peea.mx.FF.controladores;

import com.peea.mx.FF.iFrame.informacioniFrame;

/**
 *
 * @author Sistemas
 */
public class controladorInformacion {
    private informacioniFrame ii;

    public controladorInformacion(informacioniFrame ii) {
        this.ii = ii;
    }
    
    
}
